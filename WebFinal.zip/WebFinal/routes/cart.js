const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'supersecretjwtkey';

// simple auth middleware (token passed in Authorization: Bearer <token>)
const auth = (req,res,next)=>{
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({error:'No token'});
  const token = h.split(' ')[1];
  try{
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  }catch(e){ res.status(401).json({error:'Invalid token'}) }
};

// get cart for current user
router.get('/', auth, async (req,res)=>{
  const cart = await Cart.findOne({ user: req.user.id }).populate('items.product');
  res.json(cart || { items: [] });
});

// add/update item (body: productId, qty)
router.post('/add', auth, async (req,res)=>{
  const { productId, qty } = req.body;
  let cart = await Cart.findOne({ user: req.user.id });
  if(!cart){
    cart = new Cart({ user: req.user.id, items: [] });
  }
  const idx = cart.items.findIndex(i => i.product.toString() === productId);
  if(idx >= 0){
    cart.items[idx].qty = qty;
    if(qty <= 0) cart.items.splice(idx,1);
  } else {
    if(qty > 0) cart.items.push({ product: productId, qty });
  }
  cart.updatedAt = Date.now();
  await cart.save();
  await cart.populate('items.product');
  res.json(cart);
});

// remove item
router.post('/remove', auth, async (req,res)=>{
  const { productId } = req.body;
  let cart = await Cart.findOne({ user: req.user.id });
  if(!cart) return res.json({ items: [] });
  cart.items = cart.items.filter(i => i.product.toString() !== productId);
  await cart.save(); await cart.populate('items.product');
  res.json(cart);
});

// checkout: create order, clear cart
const Order = require('../models/Order');
router.post('/checkout', auth, async (req,res)=>{
  const cart = await Cart.findOne({ user: req.user.id }).populate('items.product');
  if(!cart || !cart.items.length) return res.status(400).json({ error:'Cart empty' });
  const items = cart.items.map(it => ({
    product: it.product._id,
    qty: it.qty,
    priceAtPurchase: it.product.price
  }));
  const total = items.reduce((s,i)=> s + i.qty * i.priceAtPurchase, 0);
  const order = new Order({ user: req.user.id, items, total });
  await order.save();
  cart.items = []; await cart.save();
  res.json({ orderId: order._id, total });
});

module.exports = router;
