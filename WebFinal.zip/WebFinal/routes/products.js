const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// list with optional search & category filter
router.get('/', async (req, res) => {
  try{
    const { q, category } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (q) filter.title = { $regex: q, $options: 'i' };
    const products = await Product.find(filter).sort({ createdAt: -1 });
    res.json(products);
  }catch(err){ res.status(500).json({ error: err.message }) }
});

router.get('/:id', async (req,res) => {
  try{ const p = await Product.findById(req.params.id); res.json(p) }
  catch(err){ res.status(404).json({error:'Not found'})}
});

module.exports = router;
