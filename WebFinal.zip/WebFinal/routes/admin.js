const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// Basic admin authentication using fixed credential (since user requested "fixed credentials").
// In production you'd use proper auth + roles. Here we accept a fixed token authorized by admin login.
const ADMIN_EMAIL = 'admin@example.com';
const ADMIN_PASS = 'AdminPass123';

// admin login endpoint returns a temporary token (we keep it simple)
router.post('/login', (req,res)=>{
  const { email, password } = req.body;
  if (email === ADMIN_EMAIL && password === ADMIN_PASS) {
    // produce an admin token (not JWT here for brevity)
    return res.json({ adminToken: 'admintoken-very-secret' });
  }
  return res.status(401).json({ error: 'Invalid admin credentials' });
});

// middleware
const adminAuth = (req,res,next)=>{
  const t = req.headers['x-admin-token'];
  if(t === 'admintoken-very-secret') return next();
  return res.status(401).json({ error: 'Not authorized' });
};

// add product
router.post('/product', adminAuth, async (req,res)=>{
  const { title, description, image, price, category } = req.body;
  const product = new Product({ title, description, image, price, category });
  await product.save();
  res.json(product);
});

module.exports = router;
