require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const User = require('./models/User');
const Product = require('./models/Product');
const Cart = require('./models/Cart');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static front-end
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/admin', adminRoutes);

// fallback to index
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// Connect to MongoDB then start
const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> {
    console.log('Connected to MongoDB');
    app.listen(PORT, ()=> console.log(`Server listening ${PORT}`));
  })
  .catch(err => console.error(err));

// ADD TO CART
app.post("/cart", async (req,res)=>{
  const existing = await Cart.findOne({id:req.body.id});
  if(existing){
    existing.quantity +=1;
    await existing.save();
  } else {
    await Cart.create(req.body);
  }
  res.send("Added");
});

// GET CART
app.get("/cart", async (req,res)=>{
  const cart = await Cart.find();
  res.json(cart);
});

// ADD PRODUCT
app.post("/products", async (req, res) => {
  const product = await Product.create(req.body);
  res.json(product);
});


// GET PRODUCTS
app.get("/products", async (req, res) => {
  const products = await Product.find();
  res.json(products);
});


// DELETE PRODUCT
app.delete("/products/:id", async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ msg: "Deleted" });
});

// CHANGE QTY
app.put("/cart/:id", async (req,res)=>{
  const item = await Cart.findById(req.params.id);
  item.quantity += req.body.change;

  if(item.quantity <= 0){
    await Cart.deleteOne({_id:req.params.id});
  } else {
    await item.save();
  }

  res.send("Updated");
});

const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// SIGN UP
app.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;

  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.status(400).json({ msg: "User already exists" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const user = await User.create({
    name,
    email,
    password: hashedPassword
  });

  res.json({ msg: "User registered successfully" });
});

// LOGIN
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  // ADMIN LOGIN (FIXED)
  if (email === "admin@artisanfinds.com" && password === "admin123") {
    return res.json({ msg: "Admin login success", role: "admin" });
  }

  const user = await User.findOne({ email });
  if (!user) {
    return res.status(400).json({ msg: "User not found" });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({ msg: "Wrong password" });
  }

  res.json({ msg: "Login success", role: "user" });
});
