const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
  title: String,
  description: String,
  image: String,
  price: Number,
  category: String
});

module.exports = mongoose.models.Product || mongoose.model("Product", productSchema);
