const API_URL = "http://localhost:5000";

// CART COUNT
async function updateCartCount() {
    try {
        const res = await fetch(`${API_URL}/cart`);
        const data = await res.json();
        document.getElementById("cart-item-count").innerText = data.length;
    } catch (err) {
        console.log("Cart count error:", err);
    }
}

updateCartCount();

// ========= ADD TO CART =========
document.querySelectorAll(".add-to-cart-btn").forEach(btn => {
    btn.addEventListener("click", async (e) => {
        const card = e.target.closest(".product-card");

        const product = {
            id: card.dataset.id,
            name: card.querySelector("h3").innerText,
            price: card.querySelector(".product-price").innerText.replace("₱", ""),
            img: card.querySelector("img").src,
            quantity: 1
        };

        await fetch(`${API_URL}/cart`, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(product)
        });

        updateCartCount();
        alert("✅ Added to cart!");
    });
});


// ========= BUY NOW =========
document.querySelectorAll(".buy-now-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const card = btn.closest(".product-card");
    const name = card.querySelector("h3").innerText;
    const price = card.querySelector(".product-price").innerText;

    const quantity = prompt("Enter quantity:");

    if(!quantity || isNaN(quantity)) return;

    const total = parseFloat(price.replace("₱","")) * quantity;

    if(confirm(`Buy ${name}\nQuantity: ${quantity}\nTotal: ₱${total}?`)) {
      alert("✅ Order placed successfully!");
    }
  });
});


// ========= SEARCH FILTER =========
const nav = document.querySelector(".navbar");

if(nav){
    const searchInput = document.createElement("input");
    searchInput.placeholder = "Search products...";
    searchInput.style.padding = "5px";
    searchInput.style.marginLeft = "20px";
    nav.appendChild(searchInput);

    searchInput.addEventListener("keyup", () => {
        const value = searchInput.value.toLowerCase();
        document.querySelectorAll(".product-card").forEach(card => {
            const text = card.innerText.toLowerCase();
            card.style.display = text.includes(value) ? "block" : "none";
        });
    });
}
