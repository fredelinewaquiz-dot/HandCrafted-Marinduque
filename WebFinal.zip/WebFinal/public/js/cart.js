async function loadCart(){
  const token = localStorage.getItem('token');
  if(!token) { document.getElementById('cartArea').innerHTML = '<p>Please login</p>'; return; }
  const res = await fetch('/api/cart', { headers: { 'Authorization': 'Bearer ' + token }});
  const cart = await res.json();
  const area = document.getElementById('cartArea');
  if(!cart || !cart.items || !cart.items.length) return area.innerHTML = '<p>Cart is empty</p>';
  let total = 0;
  area.innerHTML = '<div class="cart-list"></div><div class="cart-summary"></div>';
  const list = area.querySelector('.cart-list');
  cart.items.forEach(it => {
    const p = it.product;
    const row = document.createElement('div');
    row.className = 'cart-row';
    row.innerHTML = `
      <img src="${p.image||'https://via.placeholder.com/80'}">
      <div class="info"><h4>${p.title}</h4><div>₱${p.price.toFixed(2)}</div></div>
      <div class="qty-controls">
        <button class="minus">-</button>
        <input type="number" class="qty" value="${it.qty}" min="1">
        <button class="plus">+</button>
      </div>
      <div class="subtotal">₱${(p.price * it.qty).toFixed(2)}</div>
      <button class="remove">Remove</button>
    `;
    list.appendChild(row);
    total += p.price * it.qty;

    const qtyField = row.querySelector('.qty');
    row.querySelector('.plus').addEventListener('click', async () => {
      qtyField.value = +qtyField.value + 1;
      await updateQty(it.product._id, +qtyField.value);
      loadCart();
    });
    row.querySelector('.minus').addEventListener('click', async () => {
      qtyField.value = Math.max(1, +qtyField.value - 1);
      await updateQty(it.product._id, +qtyField.value);
      loadCart();
    });
    row.querySelector('.remove').addEventListener('click', async () => {
      await fetch('/api/cart/remove', { method:'POST', headers: {'Content-Type':'application/json','Authorization':'Bearer '+token}, body: JSON.stringify({ productId: it.product._id })});
      loadCart();
    });
  });

  const summary = area.querySelector('.cart-summary');
  summary.innerHTML = `<h3>Total: ₱${total.toFixed(2)}</h3><button id="checkoutBtn">Buy / Checkout</button>`;
  summary.querySelector('#checkoutBtn').addEventListener('click', async ()=>{
    if(!confirm('Proceed to checkout?')) return;
    const res = await fetch('/api/cart/checkout', { method: 'POST', headers: { 'Authorization':'Bearer ' + token }});
    const data = await res.json();
    if(res.ok){ alert('Order placed. Total: ₱' + (data.total || 0).toFixed(2)); loadCart(); }
    else alert(data.error || 'Checkout failed');
  });
}

async function updateQty(productId, qty){
  const token = localStorage.getItem('token');
  if(!token) return alert('Login required');
  await fetch('/api/cart/add', { method:'POST', headers: {'Content-Type':'application/json','Authorization':'Bearer '+token}, body: JSON.stringify({ productId, qty })});
}

loadCart();
